import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';
import { createPost, listPosts, deletePost, getMissingContent, connectPost, changePostStatus, updatePostSettings } from './commands/posts';
import { listIntegrations, listGroups, getIntegrationSettings, triggerIntegrationTool } from './commands/integrations';
import { getAnalytics, getPostAnalytics } from './commands/analytics';
import { uploadFile } from './commands/upload';
import { createClipping, listClippings, getClipping } from './commands/clipping';
import { authLogin, authLogout, authStatus } from './commands/auth';
import type { Argv } from 'yargs';

yargs(hideBin(process.argv))
  .scriptName('postiz')
  .usage('$0 <command> [options]')
  .command(
    'posts:create',
    'Create a new post',
    (yargs: Argv) => {
      return yargs
        .option('content', {
          alias: 'c',
          describe: 'Post/comment content (can be used multiple times)',
          type: 'string',
        })
        .option('media', {
          alias: 'm',
          describe: 'Comma-separated media URLs for the corresponding -c (can be used multiple times)',
          type: 'string',
        })
        .option('integrations', {
          alias: 'i',
          describe: 'Comma-separated list of integration IDs',
          type: 'string',
        })
        .option('date', {
          alias: 's',
          describe: 'Schedule date (ISO 8601 format) - REQUIRED',
          type: 'string',
        })
        .option('type', {
          alias: 't',
          describe: 'Post type: "schedule" or "draft"',
          type: 'string',
          choices: ['schedule', 'draft'],
          default: 'schedule',
        })
        .option('delay', {
          alias: 'd',
          describe: 'Delay in minutes between comments (default: 0)',
          type: 'number',
          default: 0,
        })
        .option('json', {
          alias: 'j',
          describe: 'Path to JSON file with full post structure',
          type: 'string',
        })
        .option('shortLink', {
          describe: 'Use short links',
          type: 'boolean',
          default: true,
        })
        .option('settings', {
          describe: 'Platform-specific settings as JSON string',
          type: 'string',
        })
        .check((argv) => {
          if (!argv.json && !argv.content) {
            throw new Error('Either --content or --json is required');
          }
          if (!argv.json && !argv.integrations) {
            throw new Error('--integrations is required when not using --json');
          }
          if (!argv.json && !argv.date) {
            throw new Error('--date is required when not using --json');
          }
          return true;
        })
        .example(
          '$0 posts:create -c "Hello World!" -s "2024-12-31T12:00:00Z" -i "twitter-123"',
          'Simple scheduled post'
        )
        .example(
          '$0 posts:create -c "Draft post" -s "2024-12-31T12:00:00Z" -t draft -i "twitter-123"',
          'Create draft post'
        )
        .example(
          '$0 posts:create -c "Main post" -m "img1.jpg,img2.jpg" -s "2024-12-31T12:00:00Z" -i "twitter-123"',
          'Post with multiple images'
        )
        .example(
          '$0 posts:create -c "Main post" -m "img1.jpg" -c "First comment" -m "img2.jpg" -c "Second comment" -m "img3.jpg,img4.jpg" -s "2024-12-31T12:00:00Z" -i "twitter-123"',
          'Post with comments, each having their own media'
        )
        .example(
          '$0 posts:create -c "Main" -c "Comment with semicolon; see?" -c "Another!" -s "2024-12-31T12:00:00Z" -i "twitter-123"',
          'Comments can contain semicolons'
        )
        .example(
          '$0 posts:create -c "Thread 1/3" -c "Thread 2/3" -c "Thread 3/3" -d 5 -s "2024-12-31T12:00:00Z" -i "twitter-123"',
          'Twitter thread with 5 minute delay'
        )
        .example(
          '$0 posts:create --json ./post.json',
          'Complex post from JSON file'
        )
        .example(
          '$0 posts:create -c "Post to subreddit" -s "2024-12-31T12:00:00Z" --settings \'{"subreddit":[{"value":{"subreddit":"programming","title":"My Title","type":"text","url":"","is_flair_required":false}}]}\' -i "reddit-123"',
          'Reddit post with specific subreddit settings'
        )
        .example(
          '$0 posts:create -c "Video description" -s "2024-12-31T12:00:00Z" --settings \'{"title":"My Video","type":"public","tags":[{"value":"tech","label":"Tech"}]}\' -i "youtube-123"',
          'YouTube post with title and tags'
        )
        .example(
          '$0 posts:create -c "Tweet content" -s "2024-12-31T12:00:00Z" --settings \'{"who_can_reply_post":"everyone"}\' -i "twitter-123"',
          'X (Twitter) post with reply settings'
        );
    },
    createPost as any
  )
  .command(
    'posts:list',
    'List all posts',
    (yargs: Argv) => {
      return yargs
        .option('startDate', {
          describe: 'Start date (ISO 8601 format). Default: 30 days ago',
          type: 'string',
        })
        .option('endDate', {
          describe: 'End date (ISO 8601 format). Default: 30 days from now',
          type: 'string',
        })
        .option('customer', {
          describe: 'Customer ID (optional)',
          type: 'string',
        })
        .example('$0 posts:list', 'List all posts (last 30 days to next 30 days)')
        .example(
          '$0 posts:list --startDate "2024-01-01T00:00:00Z" --endDate "2024-12-31T23:59:59Z"',
          'List posts for a specific date range'
        )
        .example(
          '$0 posts:list --customer "customer-id"',
          'List posts for a specific customer'
        );
    },
    listPosts as any
  )
  .command(
    'posts:delete <id>',
    'Delete a post',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Post ID to delete',
          type: 'string',
        })
        .example('$0 posts:delete abc123', 'Delete post with ID abc123');
    },
    deletePost as any
  )
  .command(
    'posts:missing <id>',
    'List available content from the provider for a post with missing release ID',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Post ID',
          type: 'string',
        })
        .example(
          '$0 posts:missing post-123',
          'Get available content to connect to a post'
        );
    },
    getMissingContent as any
  )
  .command(
    'posts:status <id>',
    'Change a post status between draft and schedule',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Post ID',
          type: 'string',
        })
        .option('status', {
          alias: 's',
          describe: 'New status: "draft" or "schedule"',
          type: 'string',
          choices: ['draft', 'schedule'],
          demandOption: true,
        })
        .example(
          '$0 posts:status post-123 --status draft',
          'Move a scheduled post back to draft (stops the running workflow)'
        )
        .example(
          '$0 posts:status post-123 --status schedule',
          'Schedule a draft post so it is queued for publishing'
        );
    },
    changePostStatus as any
  )
  .command(
    'posts:settings <id>',
    'Update a post\'s provider-specific settings (merged; only unpublished draft/scheduled posts)',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Post ID',
          type: 'string',
        })
        .option('settings', {
          describe: 'Partial settings as a JSON string — only the keys you pass change; do not include __type',
          type: 'string',
          demandOption: true,
        })
        .example(
          '$0 posts:settings post-123 --settings \'{"content_posting_method":"DIRECT_POST"}\'',
          'Switch a TikTok draft to direct publishing'
        )
        .example(
          '$0 posts:settings post-123 --settings \'{"subreddit":[{"value":{"subreddit":"/r/selfhosted","title":"My title","type":"self","is_flair_required":true}}]}\'',
          'Set a Reddit post\'s subreddit'
        );
    },
    updatePostSettings as any
  )
  .command(
    'posts:connect <id>',
    'Connect a post to its published content by updating the release ID',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Post ID',
          type: 'string',
        })
        .option('release-id', {
          describe: 'The platform-specific content ID to connect',
          type: 'string',
          demandOption: true,
        })
        .example(
          '$0 posts:connect post-123 --release-id "7321456789012345678"',
          'Connect a post to its published content'
        );
    },
    connectPost as any
  )
  .command(
    'integrations:list',
    'List all connected integrations',
    (yargs: Argv) => {
      return yargs
        .option('group', {
          describe: 'Filter integrations by group (customer) ID',
          type: 'string',
        })
        .example('$0 integrations:list', 'List all connected integrations')
        .example(
          '$0 integrations:list --group "customer-id"',
          'List integrations for a specific group'
        );
    },
    listIntegrations as any
  )
  .command(
    'integrations:groups',
    'List all groups (customers)',
    {},
    listGroups as any
  )
  .command(
    'integrations:settings <id>',
    'Get settings schema for a specific integration',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Integration ID',
          type: 'string',
        })
        .example(
          '$0 integrations:settings reddit-123',
          'Get settings schema for Reddit integration'
        )
        .example(
          '$0 integrations:settings youtube-456',
          'Get settings schema for YouTube integration'
        );
    },
    getIntegrationSettings as any
  )
  .command(
    'integrations:trigger <id> <method>',
    'Trigger an integration tool to fetch additional data',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Integration ID',
          type: 'string',
        })
        .positional('method', {
          describe: 'Method name from the integration tools',
          type: 'string',
        })
        .option('data', {
          alias: 'd',
          describe: 'Data to pass to the tool as JSON string',
          type: 'string',
        })
        .example(
          '$0 integrations:trigger reddit-123 getSubreddits',
          'Get list of subreddits'
        )
        .example(
          '$0 integrations:trigger reddit-123 searchSubreddits -d \'{"query":"programming"}\'',
          'Search for subreddits'
        )
        .example(
          '$0 integrations:trigger youtube-123 getPlaylists',
          'Get YouTube playlists'
        );
    },
    triggerIntegrationTool as any
  )
  .command(
    'analytics:platform <id>',
    'Get analytics for a specific integration/channel',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Integration ID',
          type: 'string',
        })
        .option('date', {
          alias: 'd',
          describe: 'Number of days to look back (default: 7)',
          type: 'string',
          default: '7',
        })
        .example(
          '$0 analytics:platform integration-123',
          'Get last 7 days of analytics'
        )
        .example(
          '$0 analytics:platform integration-123 -d 30',
          'Get last 30 days of analytics'
        );
    },
    getAnalytics as any
  )
  .command(
    'analytics:post <id>',
    'Get analytics for a specific post',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Post ID',
          type: 'string',
        })
        .option('date', {
          alias: 'd',
          describe: 'Number of days to look back (default: 7)',
          type: 'string',
          default: '7',
        })
        .example(
          '$0 analytics:post post-123',
          'Get last 7 days of post analytics'
        )
        .example(
          '$0 analytics:post post-123 -d 30',
          'Get last 30 days of post analytics'
        );
    },
    getPostAnalytics as any
  )
  .command(
    'upload <file>',
    'Upload a file',
    (yargs: Argv) => {
      return yargs
        .positional('file', {
          describe: 'File path to upload',
          type: 'string',
        })
        .example('$0 upload ./image.png', 'Upload an image');
    },
    uploadFile as any
  )
  .command(
    'clipping:create <url>',
    'Turn a long YouTube video into short vertical clips with captions',
    (yargs: Argv) => {
      return yargs
        .positional('url', {
          describe: 'URL of the YouTube video',
          type: 'string',
        })
        .option('integrations', {
          alias: 'i',
          describe: 'Comma-separated list of integration IDs to create a draft post for every clip (without it the clips only land in the media library)',
          type: 'string',
        })
        .option('clips', {
          alias: 'n',
          describe: 'Maximum number of clips, 1-10 (default: 5)',
          type: 'number',
        })
        .option('fit', {
          alias: 'f',
          describe: 'How the horizontal video fills the vertical clip: "blur" keeps the whole picture over a blurred copy of itself, "crop" fills the clip and cuts the sides (default: blur)',
          type: 'string',
          choices: ['blur', 'crop'],
        })
        .example(
          '$0 clipping:create "https://www.youtube.com/watch?v=VIDEO_ID"',
          'Clip a video into the media library'
        )
        .example(
          '$0 clipping:create "https://www.youtube.com/watch?v=VIDEO_ID" -n 3 -f crop -i "tiktok-123,instagram-456"',
          'Make up to 3 cropped clips and draft them on two channels'
        );
    },
    createClipping as any
  )
  .command(
    'clipping:list',
    'List all clippings',
    (yargs: Argv) => {
      return yargs
        .option('page', {
          alias: 'p',
          describe: 'Page number, 20 clippings per page (default: 1)',
          type: 'number',
        })
        .example('$0 clipping:list', 'List the latest clippings')
        .example('$0 clipping:list --page 2', 'List the second page');
    },
    listClippings as any
  )
  .command(
    'clipping:status <id>',
    'Get the status of a clipping and its clips',
    (yargs: Argv) => {
      return yargs
        .positional('id', {
          describe: 'Clipping ID returned by clipping:create',
          type: 'string',
        })
        .example(
          '$0 clipping:status clipping-123',
          'Check the progress and get the clip URLs'
        );
    },
    getClipping as any
  )
  .command(
    'auth:login',
    'Authenticate using OAuth2 (device flow)',
    (yargs: Argv) => {
      return yargs
        .option('auth-server', {
          describe: 'Auth server URL (default: https://cli-auth.postiz.com)',
          type: 'string',
        })
        .example(
          '$0 auth:login',
          'Login via OAuth2 device flow'
        );
    },
    authLogin as any
  )
  .command(
    'auth:logout',
    'Remove stored OAuth2 credentials',
    {},
    authLogout as any
  )
  .command(
    'auth:status',
    'Show current authentication status',
    {},
    authStatus as any
  )
  .demandCommand(1, 'You need at least one command')
  .help()
  .alias('h', 'help')
  .version()
  .alias('v', 'version')
  .epilogue(
    'For more information, visit: https://postiz.com\n\nAuthentication:\n  OAuth2: postiz auth:login\n  API Key: export POSTIZ_API_KEY=your_api_key\n\n📽️  Recommendation: Use agent-media to generate AI videos & images (Kling, Veo, Sora, Seedance, Flux, Grok) and post them directly with Postiz.\n   Install: npm install -g agent-media-cli\n   Learn more: https://agent-media.ai'
  )
  .parse();
